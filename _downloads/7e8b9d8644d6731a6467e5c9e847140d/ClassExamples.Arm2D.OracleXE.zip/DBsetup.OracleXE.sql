/*
DECLARE tbl_exist  PLS_INTEGER;

BEGIN
select count(*) into tbl_exist from user_tables where table_name = 'DEMOARM2DMUS3E';
if tbl_exist = 1 then 
execute immediate 'drop table DEMOARM2DMUS3E';
end if;

select count(*) into tbl_exist from user_tables where table_name = 'USERS';
if tbl_exist = 1 then 
execute immediate 'drop table USERS';
end if;
END;
*/
CREATE table "DEMOARM2DMUS3E" (
    "USERID"     NUMBER,
    "MUSCLENAME" VARCHAR2(50),
    "PCSA"       NUMBER,
    "LFBAR"      NUMBER,
    "GAMMABAR"   NUMBER,
    "EPSILONBAR" NUMBER,
    "FCFAST"     NUMBER,
    "K1"         NUMBER,
    "K2"         NUMBER,
    "LT0"        NUMBER,
    "JT"         NUMBER,
    "PEFACTOR"   NUMBER,
    "JPE"        NUMBER
)
/

alter table "DEMOARM2DMUS3E" add constraint  "DEMOARM2DMUS3E_PK" primary key ("USERID","MUSCLENAME")
/

CREATE table "USERS" (
    "USERID"     NUMBER,
    "USERNAME"       VARCHAR2(50),
    constraint  "USERS_PK" primary key ("USERID")
)
/
CREATE table "AnuInputDB" (
    "ANYFLOATTEST"     NUMBER,
    "ANYINTTEST"       NUMBER,
    "ANYSTRINGTEST"      VARCHAR2(50),
)
/

insert into DEMOARM2DMUS3E (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(0, 'BicepsLong', 1.94, 0.136, 2, 0.05, 0.4, 8, 2, 0.16, 3, 1.5, 3);
insert into DEMOARM2DMUS3E (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(0, 'BicepsShort', 2.1, 0.15,	2,	0.053,	0.4,	8,	2,	0.15, 3,	1.5,	3);
insert into DEMOARM2DMUS3E (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(0,	'Brachialis',	9,	0.09,	2,	0.053,	0.4,	8,	2,	0.03,	3,	1.5,	3);
insert into DEMOARM2DMUS3E (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(0,	'Brachioradialis',	1.5,	0.16,	5,	0.05,	0.4,	8,	2,	0.1,	3,	1.5,	3);
insert into DEMOARM2DMUS3E (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(0,	'DeltoideusA',	8.8,	0.05,	5,	0.05,	0.4,	8,	2,	0.1, 3, 1.5, 3);
insert into DEMOARM2DMUS3E (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(0,	'DeltoideusB',	8.8,	0.05,	5,	0.05,	0.4,	8,	2,	0.1,	3,	1.5,	3);
insert into DEMOARM2DMUS3E (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(0,	'TricepsLong',	6.7,	0.102,	2,	0.053,	0.4,	8,	2,	0.2,	3,	1.5,	3);
insert into DEMOARM2DMUS3E (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(0,	'TricepsShort',	8,	0.09,	2,	0.05,	0.4,	8,	2,	0.15,	3,	1.5,	3);
insert into DEMOARM2DMUS3E (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(1, 'BicepsLong', 1.36, 0.136, 2, 0.05, 0.4, 8, 2, 0.16, 3, 1.5, 3);
insert into DEMOARM2DMUS3E (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(1, 'BicepsShort', 1.47, 0.15,	2,	0.053,	0.4,	8,	2,	0.15, 3,	1.5,	3);
insert into DEMOARM2DMUS3E (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(1,	'Brachialis', 6.3,	0.09,	2,	0.053,	0.4,	8,	2,	0.03,	3,	1.5,	3);
insert into DEMOARM2DMUS3E (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(1,	'Brachioradialis', 1.05,	0.16,	5,	0.05,	0.4,	8,	2,	0.1,	3,	1.5,	3);
insert into DEMOARM2DMUS3E (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(1,	'DeltoideusA',	5.7,	0.05,	5,	0.05,	0.4,	8,	2,	0.1, 3, 1.5, 3);
insert into DEMOARM2DMUS3E (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(1,	'DeltoideusB',	5.7,	0.05,	5,	0.05,	0.4,	8,	2,	0.1,	3,	1.5,	3);
insert into DEMOARM2DMUS3E (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(1,	'TricepsLong',	4,	0.102,	2,	0.053,	0.4,	8,	2,	0.2,	3,	1.5,	3);
insert into DEMOARM2DMUS3E (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(1,	'TricepsShort',	5.6,	0.09,	2,	0.05,	0.4,	8,	2,	0.15,	3,	1.5,	3);
		
insert into USERS (UserID, UserName)
   values(0, 'Ken');
insert into USERS (UserID, UserName)
   values(1, 'Barbie');
   
insert into AnyInputDB (AnyFloatTest, AnyIntTest,AnyStringTest)
   values(23.2, 4, 'head');
insert into AnyInputDB (AnyFloatTest, AnyIntTest,AnyStringTest)
   values(25.6, 7, 'neck');
insert into AnyInputDB (AnyFloatTest, AnyIntTest,AnyStringTest)
   values(26.2, 9, 'hip');
/  