Demo of AnyInputDB

This folder contains two examples, where data is imported from a database into an AnyScript model using the AnyInputDB class. 
Both examples show connection to a variaty of different databases, such as MS Access, MS SQL Server, Oracle, and MySQL.

The MS Access database is included in the demo in the file DBtest.Access.mdb. Therfore the MS Acces examples run directly, whereas the other databases require a server taht must be set up before the examples can be successfully launched. To assist setting up the databases, SQL scripts, which can be run in your database system, are included in the folder. An SQl script for database type is included.

DBsetup.MySQL.sql:          This is script file to create the sample database in MySQL.
DBsetup.MS_SQLServer.sql:   This is script file to create the sample database in SQL Server.
DBsetup.OracleXE.sql:       This is script file to create the sample database in OracleXe.

The test databases contain data that support both examples.

1) Simple example
This example shows simple connection and import of data into an AnyScript model. There is a file for each database type.
AnyInputDB.<database_type>.any


2) AnyInputDB.Arm2D.any
AnyInputDB.Arm2D.any is an example of how muscle data can be collected in a database and read into a musculoskeletal model. This example is based on the simple Arm2D model.

AnyInputDB.Arm2D.DataBaseOnly.any is an include file for AnyInputDB.Arm2D.any, in which the database access is implemented.
By default this access the MS Access database in the file DBtest.Access.mdb; however, connection to other database is also illustrated in the model file. Before these connections can be used the databases must be prepared. For this sql script are included with the file. Further description is found in AnyInputDB.Arm2D.DataBaseOnly.any.
