/** 
\file IAnyBodyDefs.h
\brief Header file basic definitions

\date March, 2011
\author copyright(C) 2009-2011, AnyBody Technology A/S
*/


namespace IAnyBody
{

  /** \brief Base class for exceptions from IADataC.
  */
  enum IAError {
    NoError = 0,                     ///< Error code for successful function return, i.e. no error.
    UnspecifiedError = -1,           ///< Error code for unknown or unexpected error.
    LicenseNotValid = -2,            ///< Error code for invalid license.
    IADataWasNotInitialized = -3,    ///< Error code for IADataC data request before proper initialization.
    DimensionalityOutOfRange = -4,   ///< Error code for requested data dimensionality of out allowed.
    IndexOutOfRange = -5,            ///< Error code for requested dara index out of allowed range.
    NoTypeConversion = -6            ///< Error code for mismatch between requested and stored data type.
  };

  /** \brief Base class for data containers and encasulators.

  The class is abstract containing (purely virtual) functions as interface. 
  These interface functions are shared by the AData data containers in the AnyScript data structure
  and the AnyBody Core Interface's encapsulation of these containers, IADataC.
  */
  class IAData
  {
  public:
    virtual int GetDimensionality() const = 0;
    virtual int GetItemsQuantity() const = 0;
    virtual int GetOneSize(unsigned int n) const = 0;

    virtual int GetPos(int nIndex0) const  = 0;
    virtual int GetPos(int nIndex0, int nIndex1) const  = 0;
    virtual int GetPos(int nIndex0, int nIndex1, int nIndex2) const  = 0;
    virtual int GetPos(int nIndex0, int nIndex1, int nIndex2, int nIndex3) const  = 0;

    virtual const IAError _Get(double& Data, int Pos) const = 0;
    virtual const IAError _Get(int& Data, int Pos) const = 0;
    virtual const IAError _Get(const char*& Data, int Pos) const = 0;

    virtual const IAError _Set(const double Data, int Pos) = 0;
    virtual const IAError _Set(const int Data, int Pos) = 0;
    virtual const IAError _Set(const char* Data, int Pos) = 0;

    enum TIADataTypeID {IAFloatTypeID = 0, IAIntTypeID, IAStringTypeID, INotSupported};
    virtual TIADataTypeID GetITypeID() const = 0;
  };

  class IAString
  {
  public:
    virtual void Set(const char* pSourceStr) = 0;
    virtual void SetW(const wchar_t* pSourceStr) = 0;
    virtual const char* Get() const = 0;
    virtual const wchar_t* GetW() = 0;
  };
}