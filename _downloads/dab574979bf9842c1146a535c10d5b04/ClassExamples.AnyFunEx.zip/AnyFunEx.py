
def doit(context, x0, x1):
    t = ("test0", context[0], context[1], context[2], context[3], str(x0[0]), str(x1))
    return t
	
